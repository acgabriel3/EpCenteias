#***
#CAMINHO
#funcoes/funcionais.R

#***
#FUNCIONAIS
#Esta aba representa funcoes que auxiliam no trabalho do avaliador de sistema ou das funcoes em si

source("biblioteca/funcionais/limpeza.R")
source("biblioteca/funcionais/quantidade_para_cada_observacao.R")
source("biblioteca/funcionais/aplicacao.R")
source("biblioteca/funcionais/quantidade_de_observacoes.R")
