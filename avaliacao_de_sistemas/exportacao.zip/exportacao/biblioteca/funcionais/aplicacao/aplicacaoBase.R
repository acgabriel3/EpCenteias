
source("biblioteca/funcionais/aplicacao/aplicacaoBase/tabela_variaveis_avaliacao.R")
