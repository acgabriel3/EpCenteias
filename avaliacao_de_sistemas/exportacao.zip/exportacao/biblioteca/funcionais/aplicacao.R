#***
#Esta interface define funcoes de aplicacao a tabelas, que auxiliarao na aplicacao a multiplas partes da
#mesma, de outras funcoes dessa ou de outras bibliotecas

source("biblioteca/funcionais/aplicacao/aplicacaoBase.R")
source("biblioteca/funcionais/aplicacao/aplicacao_todas_as_colunas.R")
source("biblioteca/funcionais/aplicacao/filtro_mes_servico.R")